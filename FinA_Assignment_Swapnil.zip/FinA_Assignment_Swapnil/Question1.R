#install.packages("quadprog")
library("quadprog")
library("MASS")
#loading Covariance matrix from CSV file
cov<-read.csv(file.choose(),header=T)

#To see what is loaded in 'cov'
cov

#To see the internal structure of 'cov'
str(cov)

#So this is a dataframe. However, quadprog's solve.QP will need a matrix
covar<-as.matrix(cov[,2:9])
colnames(covar) <- c("UB","IB","ULG","ULV","USG","USV","IDE","IEE")
rownames(covar) <- c("UB","IB","ULG","ULV","USG","USV","IDE","IEE")

#Input the Returns vector:
m = c(.08,.67,6.41,4.08,7.43,3.7,4.8,6.6)/100
names(m) = colnames(covar)

#Define QP
Dmat_SV <- 2*covar
dvec_SV <- rep(0,8)
Amat_SV <- matrix(c(m,-m,rep(1,8),rep(-1,8),diag(length(m))),8,12)

# Generate 20 Required Return values, ranging from US Bonds (min) to US Small Growth (max)
min_ret = min(m)
max_ret = max(m)
range_ret = max_ret - min_ret

Rvals_SV = seq(from = min_ret, to = max_ret, by = range_ret/20)


#Define vectors to hold portfolio-variance, portfolio-std dev and asset weights for each R
varP_SV = vector()
sigmaP_SV = vector()
w1_SV = vector()
w2_SV = vector()
w3_SV = vector()
w4_SV = vector()
w5_SV = vector()
w6_SV = vector()
w7_SV = vector()
w8_SV = vector()


# Use solve.QP to find asset weights and correspontding Risk for each pre-specified value of required return, R
for(i in 1:length(Rvals_SV))
{
  #For every R
  R=Rvals_SV[i]
  
  #The corresponding b0
  bvec_SV <- c(R,-R,1,-1,rep(0,8))
  
  #print(bvec)
  
  #Solve using quadprog
  sol_SV = solve.QP(Dmat_SV,dvec_SV,Amat_SV,bvec_SV)
  
  #Store solved values for each R
  varP_SV[i] = sol_SV$value
  sigmaP_SV[i] = sqrt(varP_SV[i])
  w1_SV[i]=sol_SV$solution[1]
  w2_SV[i]=sol_SV$solution[2]
  w3_SV[i]=sol_SV$solution[3]
  w4_SV[i]=sol_SV$solution[4]
  w5_SV[i]=sol_SV$solution[5]
  w6_SV[i]=sol_SV$solution[6]
  w7_SV[i]=sol_SV$solution[7]
  w8_SV[i]=sol_SV$solution[8]
}

weights_final_SV<-data.frame(w1_SV,w2_SV,w3_SV,w4_SV,w5_SV,w6_SV,w7_SV,w8_SV)
total_weight_SV<-apply(weights_final_SV,1,sum)

#Efficient Frontier
plot(sigmaP_SV, Rvals_SV,col="red")

#Weights as visualization
t(weights_final_SV)
barplot(t(weights_final_SV),xlab="Required Returns 0.08% to 7.43%",col=rainbow(8),legend=c("UB","IB","ULG","ULV","USG","USV","IDE","IEE"),bty="n")
barplot(t(weights_final_SV),xlab="Required Returns 0.08% to 7.43%",col=rainbow(8))

#Part 2: Black Litterman 

#Define new variables
tau = .25
omega = diag(x = c(.000801,.009546,.000884))
q = matrix(c(.041,.016,.008),3,1)
P = rbind(c(0,0,0,0,0,1,0,0),c(0,0,0,0,0,0,-1,1),c(0,0,-1,0,1,0,0,0))
pi<-as.matrix(m)

#Caculate mhat
#Calculating the first term in BL method(Sum of weights = 1)
tau_cov= tau*covar
weight_1 = ginv(tau_cov)
P_transpose = t(P)
omega_inv = ginv(omega)
weight_2 <- P_transpose %*% omega_inv %*% P
first_term_before_inv = weight_1 + weight_2
first_term = ginv(first_term_before_inv)

#Calculating te second term in BL method(Sum of weighted Pi and Q)
pi_component = weight_1 %*% pi
q_component = P_transpose %*% omega_inv %*% q
second_term = pi_component + q_component

#Final mhat matrix
mhat= first_term %*% second_term
mhat<-as.vector(mhat)
names(mhat) = colnames(covar)

#Define QP
Dmat_BL <- 2*covar
dvec_BL <- rep(0,8)
Amat_BL <- matrix(c(mhat,-mhat,rep(1,8),rep(-1,8),diag(length(mhat))),8,12)

# Generate 20 Required Return values, ranging from US Bonds (min) to US Small Growth (max)
min_ret = min(mhat)
max_ret = max(mhat)
range_ret = max_ret - min_ret

Rvals_BL = seq(from = min_ret, to = max_ret, by = range_ret/20)


#Define vectors to hold portfolio-variance, portfolio-std dev and asset weights for each R
varP_BL = vector()
sigmaP_BL = vector()
w1_BL = vector()
w2_BL = vector()
w3_BL = vector()
w4_BL = vector()
w5_BL = vector()
w6_BL = vector()
w7_BL = vector()
w8_BL = vector()


# Use solve.QP to find asset weights and correspontding Risk for each pre-specified value of required return, R
for(i in 1:length(Rvals_BL))
{
  #For every R
  R=Rvals_BL[i]
  
  #The corresponding b0
  bvec_BL <- c(R,-R,1,-1,rep(0,8))
  
  #print(bvec)
  
  #Solve using quadprog
  sol_BL = solve.QP(Dmat_BL,dvec_BL,Amat_BL,bvec_BL)
  
  #Store solved values for each R
  varP_BL[i] = sol_BL$value
  sigmaP_BL[i] = sqrt(varP[i])
  w1_BL[i]=sol_BL$solution[1]
  w2_BL[i]=sol_BL$solution[2]
  w3_BL[i]=sol_BL$solution[3]
  w4_BL[i]=sol_BL$solution[4]
  w5_BL[i]=sol_BL$solution[5]
  w6_BL[i]=sol_BL$solution[6]
  w7_BL[i]=sol_BL$solution[7]
  w8_BL[i]=sol_BL$solution[8]
}

weights_final_BL<-data.frame(w1_BL,w2_BL,w3_BL,w4_BL,w5_BL,w6_BL,w7_BL,w8_BL)
total_weight_BL<-apply(weights_final_BL,1,sum)

#Efficient Frontier
plot(sigmaP_BL, Rvals_BL ,col="blue")

#Weights as visualization
t(weights_final_BL)
barplot(t(weights_final_BL),xlab="Required Returns ",col=rainbow(8),legend=c("UB","IB","ULG","ULV","USG","USV","IDE","IEE"))
barplot(t(weights_final_BL),xlab="Required Returns ",col=rainbow(8))


#Efficient frontier Plot 
par(mfrow = c(1,1))
plot(sigmaP_BL,Rvals_BL,type = 'l',lty = 1,lwd=3, xlab = 'Risk',ylab = 'Returns', main = 'Visualization of Simple variance method Vs BL method',col = 'blue')
lines(sigmaP_SV,Rvals_SV,"l",lty = 1,lwd=3,col = 'red')
legend('topleft', c("Simple variance method","BL Method"), pch = 17,  col = c('red','blue'), text.col = c('red','blue'), cex = .6)
