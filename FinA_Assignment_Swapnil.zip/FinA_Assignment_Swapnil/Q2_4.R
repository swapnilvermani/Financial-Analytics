underlying_Price=314
risk_FreeRate =0
annual_Volatility=0.3 # As found in our last step
time_To_Expiry=100
strike_Price=310

callPricer = function(p0, K, Tdays, r, sigma,  N) 
{
  numberOfTradingDays1 = 250
  
  mu_Int=r/numberOfTradingDays1
  sigma_Int=sigma/sqrt(numberOfTradingDays1)
  
  payOff = vector()
  
  for (i in 1:N)
  {
    returns=rnorm(Tdays,mu_Int,sigma_Int)
    
    p=p0
    for(j in 1:length(returns))
    {
      p = p*(1+returns[j])
    }
    
    payOff[i]=max(p-K,0)
  }
  
  optPrice = mean(payOff)/(1+r/numberOfTradingDays1)^Tdays
  return(optPrice)
}

callPrice = callPricer(underlying_Price, strike_Price, time_To_Expiry, risk_FreeRate, annual_Volatility, 1000)
callPrice
